#Requires -Version 5.1
# Quick Cloudflare Tunnel — no account needed, random URL that rotates on each run.
# Use for a 5-minute smoke test that Ollama can be reached from the internet.
# The URL is UNAUTHENTICATED — anyone with it can hit your Ollama. Don't leave running.

$ErrorActionPreference = 'Stop'

Write-Host "=== Cloudflare Quick Tunnel (smoke test) ===" -ForegroundColor Cyan
Write-Host ""

# Verify Ollama is actually listening first.
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -UseBasicParsing -TimeoutSec 3
    if ($resp.StatusCode -ne 200) { throw "Ollama returned $($resp.StatusCode)" }
    Write-Host "Ollama is up at http://localhost:11434" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Ollama does not appear to be running on localhost:11434." -ForegroundColor Red
    Write-Host "Start Ollama first, then re-run this script."
    exit 1
}

Write-Host ""
Write-Host "Starting quick tunnel. Copy the https://*.trycloudflare.com URL that appears."
Write-Host "From another PowerShell window, test with:"
Write-Host '    curl "<that-url>/api/tags"' -ForegroundColor Yellow
Write-Host ""
Write-Host "Press Ctrl+C here to stop the tunnel."
Write-Host ""

cloudflared tunnel --url http://localhost:11434
