# Cloudflare Tunnel for Ollama

Goal: expose this Windows machine's local Ollama (port 11434) to a stable public URL, so Vercel serverless functions can route AI calls to local models (free inference) instead of always falling back to cloud Claude.

**Why:** you have ~82GB of installed models (`llama3.3:70b`, `mistral-small`, `phi4:14b`, `qwen3:8b`, `gemma3:4b`, etc.) that are completely unused in production because Vercel has no path to reach `localhost:11434`. A tunnel fixes that in ~15 min.

**Cost:** $0. Cloudflare Tunnel is free; no bandwidth metering on normal use.

**Caveat:** this machine must be on for the tunnel to work. If you close the laptop or lose power, production calls fall back to cloud Claude (which is what happens today anyway — not a regression). If you need 24/7 local inference, move Ollama to the Hostinger VPS instead.

---

## Decision: Quick Tunnel or Named Tunnel?

| Option | URL stability | Needs domain? | Time to set up | Good for |
|---|---|---|---|---|
| **Quick Tunnel** | Random `*.trycloudflare.com`, rotates on restart | No | 1 min | 5-min smoke test only |
| **Named Tunnel** | Stable (`ollama.yourdomain.com`), survives restarts | Yes (on Cloudflare DNS) | 10-15 min | Production use |

**Recommended:** quick-test first to confirm Ollama is reachable end-to-end, then named tunnel for real.

---

## Prerequisites check

Before doing anything, verify Ollama is listening locally:

```powershell
curl http://localhost:11434/api/tags
```

Should return your model list. If it fails, start Ollama first.

---

## Step 1 — Install cloudflared (one time, ~2 min)

```powershell
# From this directory in PowerShell
.\1-install-cloudflared.ps1
```

This uses `winget` under the hood. If you don't have winget, the script falls back to downloading the binary directly.

Verify:
```powershell
cloudflared --version
```

---

## Step 2 — Quick Tunnel (smoke test, ~30 sec)

Run a one-shot tunnel with no account required. Gives you a random URL like `https://something-adjective-verb.trycloudflare.com`.

```powershell
.\2-quick-test.ps1
```

The script leaves the tunnel running — **open a second PowerShell window** and test:

```powershell
$url = "https://<the-url-from-step-2>.trycloudflare.com"
curl "$url/api/tags"
```

If you see your model list, the tunnel works. **Ctrl+C the first window to stop it.**

> ⚠️ Quick Tunnel URLs are unauthenticated — anyone with the URL can hit your Ollama. Don't leave one running. Only use for testing.

---

## Step 3 — Named Tunnel (production, ~10 min)

### 3a. Make sure you have a domain on Cloudflare DNS

You have three options:

1. **Move one of your existing domains to Cloudflare DNS.** Free. Takes 1-24 hours for nameserver propagation. `valuetovictory.com` keeps pointing to Vercel — you'd just swap DNS providers. Steps: Cloudflare dashboard → Add Site → enter `valuetovictory.com` → follow the guide to update GoDaddy nameservers.
2. **Buy a cheap domain directly from Cloudflare.** ~$9-10/yr for `.com`. Use it only for the tunnel (e.g., `sde-ollama.com`). Cleanest separation, zero risk to your production domains.
3. **Skip and stay on Quick Tunnel.** Fine if you just want to experiment.

### 3b. Run the setup script

```powershell
.\3-named-tunnel-setup.ps1
```

The script walks you through:
1. `cloudflared tunnel login` → opens a browser for Cloudflare auth
2. Creates a tunnel (you pick a name, e.g., `ollama-local`)
3. Asks for the hostname you want (e.g., `ollama.valuetovictory.com`)
4. Writes `~/.cloudflared/config.yml` for you
5. Offers to install as a Windows service so it auto-starts on boot

After it finishes, verify from anywhere on the internet:

```powershell
curl https://ollama.yourdomain.com/api/tags
```

Should return your model list.

---

## Step 4 — Point Vercel at the tunnel

See [vercel-env.md](vercel-env.md) for the exact env vars to set and how to verify from the app side. Short version:

- `OLLAMA_HOST` = `https://ollama.yourdomain.com`
- `AI_PROVIDER` = `auto`

Redeploy. The tier router in `api/ai.js` will now route action-specific calls to local Ollama first, falling back to Anthropic Haiku/Opus only on failure.

---

## Files in this package

| File | Purpose |
|---|---|
| `1-install-cloudflared.ps1` | Install cloudflared |
| `2-quick-test.ps1` | Start a trycloudflare.com quick tunnel (ephemeral) |
| `3-named-tunnel-setup.ps1` | Interactive named tunnel setup (login + create + run) |
| `config.yml.example` | Reference config if you want to edit by hand |
| `vercel-env.md` | Vercel env var updates + smoke test |

---

## Teardown

Named tunnel:
```powershell
cloudflared service uninstall          # if installed as service
cloudflared tunnel delete ollama-local # deletes the tunnel
# Optionally remove DNS record in Cloudflare dashboard
```

Quick tunnel: just Ctrl+C the running process. No cleanup needed.
