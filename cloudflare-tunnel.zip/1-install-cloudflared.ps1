#Requires -Version 5.1
# Install cloudflared on Windows. Tries winget first, falls back to direct binary download.

$ErrorActionPreference = 'Stop'

Write-Host "=== cloudflared install ===" -ForegroundColor Cyan

# If already installed, skip.
$existing = Get-Command cloudflared -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "cloudflared already installed at: $($existing.Source)" -ForegroundColor Green
    & cloudflared --version
    exit 0
}

# Try winget.
$hasWinget = Get-Command winget -ErrorAction SilentlyContinue
if ($hasWinget) {
    Write-Host "Installing via winget..."
    try {
        winget install --id Cloudflare.cloudflared --accept-source-agreements --accept-package-agreements --silent
        Write-Host "Installed via winget." -ForegroundColor Green
        # Refresh PATH so cloudflared resolves in this session
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        & cloudflared --version
        exit 0
    } catch {
        Write-Host "winget install failed: $_" -ForegroundColor Yellow
        Write-Host "Falling back to direct binary download..."
    }
}

# Fallback: download the latest release binary directly.
$installDir = "$env:LOCALAPPDATA\Programs\cloudflared"
New-Item -ItemType Directory -Force -Path $installDir | Out-Null

$downloadUrl = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
$binPath = Join-Path $installDir "cloudflared.exe"

Write-Host "Downloading from $downloadUrl..."
Invoke-WebRequest -Uri $downloadUrl -OutFile $binPath -UseBasicParsing

# Add installDir to user PATH if not already there.
$userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$installDir*") {
    Write-Host "Adding $installDir to user PATH"
    [System.Environment]::SetEnvironmentVariable("Path", "$userPath;$installDir", "User")
    $env:Path = "$env:Path;$installDir"
}

Write-Host "`nInstalled to: $binPath" -ForegroundColor Green
& $binPath --version

Write-Host "`nYou may need to open a new PowerShell window for PATH changes to take effect." -ForegroundColor Yellow
