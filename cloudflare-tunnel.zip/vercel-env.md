# Vercel env vars after the tunnel is live

Once `curl https://ollama.yourdomain.com/api/tags` returns your model list from anywhere on the internet, wire Vercel up.

## Path

Vercel Dashboard → `danddappraisal-7740` → Projects → `vtv-assessment` → Settings → Environment Variables

## Set these for the Production environment

| Variable | Value | What it does |
|---|---|---|
| `OLLAMA_HOST` | `https://ollama.yourdomain.com` | Where `api/ai.js` reaches Ollama. Default was `http://localhost:11434` which is unreachable from Vercel. |
| `AI_PROVIDER` | `auto` | Probes Ollama first; falls back to Anthropic Haiku/Opus if down. |

Save, then **redeploy** — env changes don't apply to the current deployment. Either push any commit to master or hit Deployments → Redeploy on the latest.

## Verify from production

```bash
curl -X POST https://assessment.valuetovictory.com/api/ai \
  -H "Content-Type: application/json" \
  -H "x-api-key: $ADMIN_API_KEY" \
  -d '{"action":"health"}'
```

Response should include:
- `ollama.available: true`
- `ollama.host: "https://ollama.yourdomain.com"`
- `ollama.models: ["llama3.3:latest", "qwen3:8b", ...]`

If `ollama.available: false`, check:
1. Is your Windows machine on?
2. Is cloudflared running? (`Get-Service Cloudflared` should show `Running`)
3. Is Ollama running? (`curl http://localhost:11434/api/tags` locally)

## Optional: per-action overrides

You can pin specific actions to specific Ollama models via env vars (all optional):

| Variable | Default |
|---|---|
| `LOCAL_MODEL_COACHING` | `qwen3:8b` |
| `LOCAL_MODEL_SUMMARY` | `mistral-small` |
| `LOCAL_MODEL_EMAIL` | `qwen3:8b` |
| `LOCAL_MODEL_CONTENT` | `qwen3:8b` |
| `LOCAL_MODEL_DEVOTIONAL` | `mistral-small` |

For example, route assessment summaries to the 70B model for higher quality:
```
LOCAL_MODEL_SUMMARY=llama3.3:latest
```
(Note: the 70B is 42GB and slow — use only for non-latency-sensitive tasks.)

## Cost impact

With Ollama reachable from prod:

| Action | Previous (Anthropic) | New (Ollama) | Fallback if Ollama down |
|---|---|---|---|
| coaching-insight | Haiku — paid | qwen3:8b — free | → Haiku |
| assessment-summary | Haiku — paid | mistral-small — free | → Haiku |
| devotional-generate | Haiku — paid | mistral-small — free | → Haiku |
| content-generate (simple) | Haiku — paid | qwen3:8b — free | → Haiku |
| content-generate (complex) | Opus — paid | Opus — paid | (stays frontier) |
| email-draft | Opus — paid | Opus — paid | (intentionally frontier) |

Rough estimate: **60-80% cost reduction** depending on traffic mix. Quality delta is small for coaching/assessment tasks — `qwen3:8b` and `mistral-small` handle those patterns fine. Email drafting and complex content-generate stay on Opus because accuracy/voice matter more.

## Rollback

If anything breaks, set `AI_PROVIDER=cloud` in Vercel and redeploy. The tier router will ignore Ollama entirely and route everything through Anthropic. Zero code change needed.
